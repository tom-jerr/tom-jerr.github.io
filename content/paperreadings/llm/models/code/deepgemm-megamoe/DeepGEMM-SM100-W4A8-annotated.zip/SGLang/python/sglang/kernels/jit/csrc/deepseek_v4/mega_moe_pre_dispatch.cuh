// [中文注释] 来源：sgl-project/sglang@f47d89564dc2479be8e2e866a2b17f149318758e
// [中文注释] 原文件：python/sglang/kernels/jit/csrc/deepseek_v4/mega_moe_pre_dispatch.cuh；保留全部原代码，仅添加本前缀的中文注释。
// [中文注释] L 号均指原文件；本地行号映射见 manifest.json。阅读包需原仓 CUDA/CUTLASS 等依赖，未进行 GPU 编译运行。
#include <sgl_kernel/tensor.h>
#include <sgl_kernel/utils.h>

#include <sgl_kernel/math.cuh>
#include <sgl_kernel/type.cuh>
#include <sgl_kernel/utils.cuh>
#include <sgl_kernel/vec.cuh>
#include <sgl_kernel/warp.cuh>

#include <sgl_kernel/deepseek_v4/fp8_utils.cuh>

#include <algorithm>
#include <cstdint>
#include <cuda_fp8.h>

namespace sglang {

using deepseek_v4::fp8::cast_to_ue8m0;
using deepseek_v4::fp8::pack_fp8;

// CUDA block-size ceiling. One CTA per token row, so a row wider than
// kMaxBlockThreads * 8 bf16 elements is covered in several strided chunks.
inline constexpr uint32_t kMaxBlockThreads = 1024;

// [中文注释] 原始 L25：前置 kernel 将 BF16 input 量化为 FP8，并复制已算好的 top-k ids/weights 到 symmetric buffer；它不执行专家 GEMM，也不在这里重算 router。
struct MegaMoEPreDispatchParams {
  const bf16_t* __restrict__ x;            // [num_tokens, hidden]
  const int32_t* __restrict__ topk_idx;    // [num_tokens, top_k]
  const float* __restrict__ topk_weights;  // [num_tokens, top_k]

  fp8_e4m3_t* __restrict__ buf_x;        // [padded_max, hidden]
  int32_t* __restrict__ buf_x_sf;        // row-major int32 [P, G/4]
  int64_t* __restrict__ buf_topk_idx;    // [padded_max, top_k]
  float* __restrict__ buf_topk_weights;  // [padded_max, top_k]
  int32_t* __restrict__ shared_x_sf;     // column-major, BLOCK_M-paged scales

  uint64_t buf_x_sf_stride_bytes;
  uint64_t shared_x_sf_col_stride;
  uint32_t shared_block_m;
  uint32_t num_tokens;
  uint32_t padded_max;
  uint32_t hidden;
  uint32_t num_groups;  // hidden / group_size
  uint32_t top_k;
};

// kGroupSize must match sglang_per_token_group_quant_fp8_ue8m0(group_size=).
// kMultiChunk covers rows too wide for one chunk per thread. It is a template
// parameter rather than a runtime check because this kernel is issue-bound: the
// loop bookkeeping alone costs ~10% on the rows that fit a single chunk.
// [中文注释] 原始 L50：每个有效 token 一 CTA。每线程向量加载 8 个 BF16=16B；group_size=32 时四个线程组成一个 quant group。宽行按多个 chunk 覆盖。
template <uint32_t kGroupSize, bool kUsePDL, bool kMultiChunk, bool kWriteSharedSF>
__global__ __launch_bounds__(kMaxBlockThreads, 2) void  //
    mega_moe_pre_dispatch_kernel(const MegaMoEPreDispatchParams __grid_constant__ params) {
  using namespace device;

  constexpr uint32_t kVecElems = 8;  // 8 bf16 = 16B load per thread
  static_assert(kGroupSize % kVecElems == 0, "group_size must be a multiple of 8");
  constexpr uint32_t kThreadsPerGroup = kGroupSize / kVecElems;
  static_assert(kMaxBlockThreads % kThreadsPerGroup == 0, "block must stride by whole quant groups");
  using InputVec = AlignedVector<bf16x2_t, kVecElems / 2>;
  using OutputVec = AlignedVector<fp8x2_e4m3_t, kVecElems / 2>;

  const uint32_t bid = blockIdx.x;
  const uint32_t tid = threadIdx.x;

// [中文注释] 原始 L65：等待上游 PDL primary 的数据依赖。结束时触发 secondary，让后续 MegaMoE 按 CUDA programmatic dependency 契约等待前置工作。
  PDLWaitPrimary<kUsePDL>();
  if (bid < params.num_tokens) {
    // ---- Quantize path: one CTA per valid token ----

    const uint32_t token_id = bid;
    const auto token_in = params.x + static_cast<uint64_t>(token_id) * params.hidden;
    const auto token_out = params.buf_x + static_cast<uint64_t>(token_id) * params.hidden;
    uint32_t shared_row = 0;
// [中文注释] 原始 L73：若 shared expert 融合，额外复制一份符合 UTCCP 分页布局的 scale；shared L1 激活本身可以直接复用 source input。
    if constexpr (kWriteSharedSF) {
      const uint32_t m = token_id % params.shared_block_m;
      shared_row = token_id / params.shared_block_m * ((params.shared_block_m + 127u) / 128u * 128u) + m / 128u * 128u +
                   m % 32u * 4u + m % 128u / 32u;
    }

    const auto quantize_chunk = [&](uint32_t chunk) {
      InputVec in_vec;
      in_vec.load(token_in, chunk);

      float local_max = 0.0f;
      float vals[kVecElems];
#pragma unroll
      for (uint32_t i = 0; i < kVecElems / 2; ++i) {
        const auto [v0, v1] = cast<fp32x2_t>(in_vec[i]);
        vals[2 * i + 0] = v0;
        vals[2 * i + 1] = v1;
        local_max = fmaxf(local_max, fmaxf(fabsf(v0), fabsf(v1)));
      }

// [中文注释] 原始 L93：先线程内求 absmax，再 group threads 间 reduce_max，算 scale=absmax/448，转换成 UE8M0 exponent，用精确 power-of-two reciprocal 缩放后量化。
      // Absmax across the kThreadsPerGroup threads that cover one group.
      local_max = warp::reduce_max<kThreadsPerGroup>(local_max);

      const float absmax = fmaxf(local_max, 1e-10f);
      const float raw_scale = absmax / math::FP8_E4M3_MAX;
      const uint32_t ue8m0_exp = cast_to_ue8m0(raw_scale);
      // 2^-ue8m0_exp as fp32 (equivalent to 1 / __uint_as_float(ue8m0 << 23)).
      const float inv_scale = __uint_as_float((127u + 127u - ue8m0_exp) << 23);

      OutputVec out_vec;
#pragma unroll
      for (uint32_t i = 0; i < kVecElems / 2; ++i) {
        out_vec[i] = pack_fp8(vals[2 * i + 0] * inv_scale, vals[2 * i + 1] * inv_scale);
      }
      out_vec.store(token_out, chunk);

// [中文注释] 原始 L109：每 group 一个 UE8M0 byte，四个 group bytes 装入 int32。stride 使用物理 padding 后的行距，不能假定所有 shape 都是紧密 H/32 byte。
      // One thread per group writes its UE8M0 byte into the row-major int32-
      // packed layout. DeepGEMM may pad each row to preserve TMA alignment.
      const uint32_t group_id = chunk / kThreadsPerGroup;
      const uint32_t within_group_id = chunk % kThreadsPerGroup;
      if (within_group_id == 0 && group_id < params.num_groups) {
        const uint64_t byte_off = static_cast<uint64_t>(token_id) * params.buf_x_sf_stride_bytes + group_id;
        reinterpret_cast<uint8_t*>(params.buf_x_sf)[byte_off] = static_cast<uint8_t>(ue8m0_exp);
        if constexpr (kWriteSharedSF) {
          const uint64_t off = shared_row + static_cast<uint64_t>(group_id / 4u) * params.shared_x_sf_col_stride;
          reinterpret_cast<uint8_t*>(params.shared_x_sf)[off * sizeof(int32_t) + group_id % 4u] =
              static_cast<uint8_t>(ue8m0_exp);
        }
      }
    };

    if constexpr (kMultiChunk) {
      // The reduce_max in quantize_chunk shuffles with a full-warp mask:
      // blockDim.x is a multiple of kThreadsPerGroup and the host pins the tail
      // iteration to whole warps, so each quant group stays on converged
      // consecutive lanes.
      const uint32_t num_chunks = params.hidden / kVecElems;
      for (uint32_t chunk = tid; chunk < num_chunks; chunk += blockDim.x) {
        quantize_chunk(chunk);
      }
    } else {
      quantize_chunk(tid);
    }

// [中文注释] 原始 L137：复制 valid token 的 top-k id（int32→int64）和 FP32 weight。MegaMoE dispatch 的源 metadata 都由这些 ids 推出。
    // Copy this token's topk row (no alignment assumptions; top_k is small).
    if (tid < params.top_k) {
      const uint32_t off = token_id * params.top_k + tid;
      params.buf_topk_idx[off] = params.topk_idx[off];
      params.buf_topk_weights[off] = params.topk_weights[off];
    }
// [中文注释] 原始 L143：padding token 的路由写 -1、weight 写 0，使 main kernel 的 read_topk_idx 自然跳过。activation padding 不需要逐行量化。
  } else {
    // ---- Pad path: trailing blocks fill [num_tokens, padded_max) with (-1, 0) ----
    const uint32_t copy_bid = bid - params.num_tokens;
    const uint32_t pad_base = params.num_tokens * params.top_k;
    const uint32_t slot = pad_base + copy_bid * blockDim.x + tid;
    const uint32_t total_slots = params.padded_max * params.top_k;

    if (slot < total_slots) {
      params.buf_topk_idx[slot] = -1;
      params.buf_topk_weights[slot] = 0.0f;
    }
  }
// [中文注释] 原始 L155：PDLTriggerSecondary 允许依赖 kernel 被启动；主 kernel 的 cudaGridDependencySynchronize 再保证它开始读取时前置结果已满足依赖。
  PDLTriggerSecondary<kUsePDL>();
}

// [中文注释] 原始 L158：以下 host wrapper 校验 tensor dtype/shape/stride，并按 hidden 宽度选择 one_chunk 或 multi_chunk 特化。阅读 package 时须同时核对这个前置路径。
// ---- Host wrapper
// ------------------------------------------------------------------------------------------------------------------------

template <int64_t kGroupSize, bool kUsePDL, bool kWriteSharedSF>
struct MegaMoEPreDispatchKernel {
  static_assert(kGroupSize == 32 || kGroupSize == 64 || kGroupSize == 128, "unsupported group_size");
  static constexpr auto kernel_one_chunk =
      mega_moe_pre_dispatch_kernel<static_cast<uint32_t>(kGroupSize), kUsePDL, false, kWriteSharedSF>;
  static constexpr auto kernel_multi_chunk =
      mega_moe_pre_dispatch_kernel<static_cast<uint32_t>(kGroupSize), kUsePDL, true, kWriteSharedSF>;

  static void
  run(const tvm::ffi::TensorView x,
      const tvm::ffi::TensorView topk_idx,
      const tvm::ffi::TensorView topk_weights,
      const tvm::ffi::TensorView buf_x,
      const tvm::ffi::TensorView buf_x_sf,
      const tvm::ffi::TensorView buf_topk_idx,
      const tvm::ffi::TensorView buf_topk_weights,
      const tvm::ffi::Optional<tvm::ffi::TensorView> shared_x_sf,
      const int64_t shared_block_m) {
    using namespace host;

    auto device = SymbolicDevice{};
    auto M = SymbolicSize{"num_tokens"};
    auto P = SymbolicSize{"padded_max"};
    auto H = SymbolicSize{"hidden"};
    auto K = SymbolicSize{"top_k"};
    auto G4 = SymbolicSize{"num_groups_div_4"};
    device.set_options<kDLCUDA>();

    TensorMatcher({M, H})  // input x
        .with_dtype<bf16_t>()
        .with_device(device)
        .verify(x);
    TensorMatcher({M, K})  // topk_idx
        .with_dtype<int32_t>()
        .with_device(device)
        .verify(topk_idx);
    TensorMatcher({M, K})  // topk_weights
        .with_dtype<float>()
        .with_device(device)
        .verify(topk_weights);
    // DeepGEMM versions expose this fp8 dispatch buffer either as raw int8
    // storage or as torch.float8_e4m3fn; the kernel writes fp8 bytes in both.
    TensorMatcher({P, H})  // buf.x
        .with_dtype<int8_t, fp8_e4m3_t>()
        .with_device(device)
        .verify(buf_x);
    // DeepGEMM exposes only the logical G scale bytes but may pad its physical
    // row stride to 16 bytes for TMA (for example, H=2304 is 72B -> 80B).
    TensorMatcher({P, G4})  // buf_x_sf
        .with_strides({-1, 1})
        .with_dtype<int32_t>()
        .with_device(device)
        .verify(buf_x_sf);
    TensorMatcher({P, K})  // buf.topk_idx
        .with_dtype<int64_t>()
        .with_device(device)
        .verify(buf_topk_idx);
    TensorMatcher({P, K})  // buf.topk_weights
        .with_dtype<float>()
        .with_device(device)
        .verify(buf_topk_weights);

    const auto num_tokens = static_cast<uint32_t>(M.unwrap());
    const auto padded_max = static_cast<uint32_t>(P.unwrap());
    const auto hidden = static_cast<uint32_t>(H.unwrap());
    const auto top_k = static_cast<uint32_t>(K.unwrap());
    const auto num_groups_div_4 = static_cast<uint32_t>(G4.unwrap());

    RuntimeCheck(num_tokens <= padded_max, "num_tokens must not exceed padded_max");
    RuntimeCheck(hidden % kGroupSize == 0, "hidden must be a multiple of group_size");
    const auto num_groups = hidden / static_cast<uint32_t>(kGroupSize);
    RuntimeCheck(num_groups == num_groups_div_4 * 4u, "num_groups must be a multiple of 4");
    RuntimeCheck(
        buf_x_sf.stride(0) >= static_cast<int64_t>(num_groups_div_4),
        "buf_x_sf row stride is smaller than its logical row width");
    const auto buf_x_sf_stride_bytes = static_cast<uint64_t>(buf_x_sf.stride(0)) * sizeof(int32_t);
    RuntimeCheck(buf_x_sf_stride_bytes % 16u == 0, "buf_x_sf row stride must be 16B-aligned");
    RuntimeCheck(
        reinterpret_cast<uintptr_t>(buf_x_sf.data_ptr()) % 16u == 0, "buf_x_sf base address must be 16B-aligned");
    RuntimeCheck(hidden % 8u == 0, "hidden must be a multiple of 8 (16B bf16 loads)");
    const auto num_chunks = hidden / 8u;
    const auto block_size = std::min(num_chunks, kMaxBlockThreads);
    const bool one_chunk_per_thread = num_chunks <= kMaxBlockThreads;
    // The quant group absmax is a full-warp-mask shuffle, so either the row fits
    // one iteration or its tail iteration is entered by whole warps.
    RuntimeCheck(
        one_chunk_per_thread || num_chunks % device::kWarpThreads == 0,
        "hidden above 8192 must be a multiple of 256 so the tail quant chunks fill whole warps");
    RuntimeCheck(block_size >= top_k, "top_k must fit into one quant CTA");

    int32_t* shared_sf_ptr = nullptr;
    uint64_t shared_sf_stride = 0;
    if constexpr (kWriteSharedSF) {
      RuntimeCheck(kGroupSize == 32, "shared MegaMoE scales require group_size=32");
      RuntimeCheck(shared_block_m > 0, "shared_block_m must be positive");
      auto S = SymbolicSize{"shared_sf_rows"};
      const auto sf = shared_x_sf.value();
      TensorMatcher({S, G4}).with_strides({1, -1}).with_dtype<int32_t>().with_device(device).verify(sf);
      const auto rows = (num_tokens + shared_block_m - 1) / shared_block_m * ((shared_block_m + 127) / 128 * 128);
      RuntimeCheck(S.unwrap() >= rows, "shared scale buffer is too small for shared_block_m");
      RuntimeCheck(sf.stride(1) >= S.unwrap(), "shared scale columns must not overlap");
      shared_sf_ptr = static_cast<int32_t*>(sf.data_ptr());
      shared_sf_stride = sf.stride(1);
    }

    const auto pad_slots = (padded_max - num_tokens) * top_k;
    const uint32_t num_pad_blocks = pad_slots == 0 ? 0u : ((pad_slots + block_size - 1u) / block_size);
    const auto num_total_blocks = num_tokens + num_pad_blocks;

    const auto params = MegaMoEPreDispatchParams{
        .x = static_cast<const bf16_t*>(x.data_ptr()),
        .topk_idx = static_cast<const int32_t*>(topk_idx.data_ptr()),
        .topk_weights = static_cast<const float*>(topk_weights.data_ptr()),
        .buf_x = static_cast<fp8_e4m3_t*>(buf_x.data_ptr()),
        .buf_x_sf = static_cast<int32_t*>(buf_x_sf.data_ptr()),
        .buf_topk_idx = static_cast<int64_t*>(buf_topk_idx.data_ptr()),
        .buf_topk_weights = static_cast<float*>(buf_topk_weights.data_ptr()),
        .shared_x_sf = shared_sf_ptr,
        .buf_x_sf_stride_bytes = buf_x_sf_stride_bytes,
        .shared_x_sf_col_stride = shared_sf_stride,
        .shared_block_m = static_cast<uint32_t>(shared_block_m),
        .num_tokens = num_tokens,
        .padded_max = padded_max,
        .hidden = hidden,
        .num_groups = num_groups,
        .top_k = top_k,
    };

    if (num_total_blocks == 0) return;
    if (one_chunk_per_thread) {
      LaunchKernel(num_total_blocks, block_size, device.unwrap())  //
          .enable_pdl(kUsePDL)(kernel_one_chunk, params);
    } else {
      LaunchKernel(num_total_blocks, block_size, device.unwrap())  //
          .enable_pdl(kUsePDL)(kernel_multi_chunk, params);
    }
  }
};

}  // namespace sglang
